package thehippomaster.AnimationAPI;

public class CommonProxy {
	
	public void initTimer() {
	}
	
	public float getPartialTick() {
		return 1F;
	}
}
